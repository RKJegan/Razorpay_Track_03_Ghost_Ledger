# Ghost Ledger v2 (base) — how to test on your system

This is the v2 project exactly as it was at commit 7a8a669 (the starting point for v3).

    python3.12 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    pytest tests -q                  # 127 tests
    python main.py --no-autopsy      # the v2 pipeline (about 1-2 minutes)
    streamlit run dashboard/app.py   # http://localhost:8501

The database and model are not in this archive; the first pipeline run creates them.
See docs/PROJECT_GUIDE.md for the full guide.

Verification note: checked in the build sandbox on Python 3.11 with xgboost 3.2.0 (the pinned
xgboost 3.4.1 needs Python 3.12). Run the same commands on Python 3.12 with the pinned requirements.
