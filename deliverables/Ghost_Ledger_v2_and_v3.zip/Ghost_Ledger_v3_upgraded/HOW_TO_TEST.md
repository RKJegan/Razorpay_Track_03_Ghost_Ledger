# Ghost Ledger v3 (upgraded) — how to test on your system

v3 = v2 plus the real-time platform (Track A) and the multi-strategy engine (Track B).
One project, one SQLite database (migrations are idempotent).

## 1. Install
    python3.12 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env            # optional; tests and the demo need no keys

## 2. Run every test (292 tests, about 70 seconds)
    pytest tests -q

## 3. Real-time transaction and recovery demo (no Razorpay account needed)
Terminal 1 — API (webhooks, approvals, merchant API):
    export RAZORPAY_WEBHOOK_SECRET=<any long random string>
    export OPERATOR_API_KEY=<any long random string>
    uvicorn api.main:app --host 0.0.0.0 --port 8000
Terminal 2 — the same RAZORPAY_WEBHOOK_SECRET must be set here too:
    python scripts/e2e_test_mode.py --mode offline
Expect 15 [PASS] lines and "Result: PASS". The script posts signed webhooks: a payment fails,
the second link is created, the second payment succeeds, and the recovery settles.
Watch it on the live progress page:
    export OPERATOR_API_KEY=<same value as terminal 1>
    streamlit run dashboard/live_progress.py --server.port 8502     # http://localhost:8502

For real Razorpay Test Mode (your own test keys, a public webhook URL through a tunnel), see
docs/PROJECT_GUIDE.md section 7 and `python scripts/e2e_test_mode.py --mode live`.

## 4. Strategy engine (Track B) — off by default
    ENABLE_ADVANCED_STRATEGIES=1 python main.py --no-autopsy     # prints the playbook summary first
    python scripts/retry_timing_holdout.py                       # simulated outcomes; see docs/STRATEGIES.md

## 5. Other dashboards
    streamlit run dashboard/app.py          # v2 recovery dashboard, http://localhost:8501
    http://localhost:8000/merchant          # merchant page (needs a merchant key; see below)

Create a merchant on your machine (the key is printed once):
    python -m database.merchants create --id <id> --name "<name>"

## Guides in this archive
- docs/PROJECT_GUIDE.md: what the project does, how to run every piece, endpoints, configuration, troubleshooting.
- docs/MODULE_GUIDE.md: what each source file does.
- docs/VSCODE_TEST_GUIDE.md: testing and running in VS Code (launch configurations in .vscode/launch.json).
- docs/STRATEGIES.md: the Track B strategy engine.

## Notes
- The generated database and models are not in this archive. The first run creates them.
- No webhook secret or API key is in this archive. Set your own in .env or the environment.
- The strategy engine uses no LLM. Customer text comes from playbook templates.

## Verification note
Checked in the build sandbox on Python 3.11 with xgboost 3.2.0 (the pinned xgboost 3.4.1 needs
Python 3.12). Run the same commands on Python 3.12 with the pinned requirements.
